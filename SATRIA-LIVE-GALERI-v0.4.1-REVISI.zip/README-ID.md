# SATRIA LIVE — Video Galeri 0.4.1

Aplikasi Android sederhana untuk memilih dan memutar video yang tersimpan di galeri ponsel.

## Fitur
- Pilih video melalui pemilih dokumen Android.
- Preview dengan AndroidX Media3 ExoPlayer.
- Putar / jeda, loop, mute, dan pengaturan volume.
- Rotasi manual 90° untuk video yang tampil miring.
- Mirror horizontal.
- Mode Fit (default, seluruh video terlihat) dan Zoom.
- Layar penuh.
- Watermark logo SATRIA pada preview.

## Build APK
1. Letakkan isi folder proyek ini pada direktori `SATRIA-LIVE` di repository.
2. Pastikan workflow GitHub Actions menggunakan direktori kerja `SATRIA-LIVE`.
3. Jalankan workflow build.
4. Unduh APK dari bagian Artifacts setelah workflow berhasil.

## Batasan
Aplikasi ini hanya memutar video galeri di layar ponsel. Aplikasi tidak membuat kamera virtual, tidak mengirim video sebagai input kamera TikTok, dan tidak menggantikan fitur LIVE platform. Untuk menampilkan video pada siaran, gunakan fitur berbagi layar jika aplikasi LIVE mendukungnya.

- Package: `id.satria.live`
- Version: `0.4.1` (versionCode 5)
- Minimum Android: 8.0 (API 26)
