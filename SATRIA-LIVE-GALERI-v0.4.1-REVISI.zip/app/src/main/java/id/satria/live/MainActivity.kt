package id.satria.live

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

private val Navy = Color(0xFF080D18)
private val Panel = Color(0xFF121C2D)
private val Cyan = Color(0xFF43D5FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SatriaLiveGalleryApp() }
    }
}

@Composable
private fun SatriaLiveGalleryApp() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var loop by remember { mutableStateOf(true) }
    var muted by remember { mutableStateOf(false) }
    var mirror by remember { mutableStateOf(false) }
    var fitMode by remember { mutableStateOf(true) }
    var rotationDegrees by remember { mutableIntStateOf(0) }
    var volume by remember { mutableFloatStateOf(1f) }
    var fullscreen by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Pilih video dari galeri untuk memulai") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) { }
            videoUri = uri
            isPlaying = false
            message = "Video galeri siap diputar"
        }
    }

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                message = if (playing) "Video sedang diputar" else "Video dijeda"
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && !loop) message = "Video selesai"
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                message = "Video tidak dapat diputar. Coba pilih file video lain."
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(videoUri, loop, muted, volume) {
        player.repeatMode = if (loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        player.volume = if (muted) 0f else volume
        videoUri?.let {
            player.setMediaItem(MediaItem.fromUri(it))
            player.prepare()
            player.playWhenReady = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
        Column(
            Modifier.fillMaxSize().background(Navy).padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.foundation.Image(
                    painter = painterResource(id = R.drawable.satria_logo),
                    contentDescription = "Logo SATRIA",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(68.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("SATRIA LIVE", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("VIDEO GALERI", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                }
                Text("GALERI", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(22.dp))
            Text("PEMUTAR VIDEO GALERI", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("Pilih dan putar video yang tersimpan di galeri ponsel.",
                color = Color.LightGray, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))

            Box(
                Modifier.fillMaxWidth().weight(1f).background(Panel, RoundedCornerShape(20.dp)).padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                        .background(Color.Black, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (videoUri == null) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxSize().clickable { picker.launch(arrayOf("video/*")) },
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.VideoLibrary, null, tint = Cyan, modifier = Modifier.size(62.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("VIDEO GALERI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Belum ada video dipilih", color = Color.Gray, fontSize = 12.sp)
                            Spacer(Modifier.height(10.dp))
                            Text("KETUK UNTUK MEMILIH", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        AndroidView(
                            factory = { PlayerView(it).apply {
                                this.player = player
                                useController = false
                                resizeMode = if (fitMode) AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    else AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                setShutterBackgroundColor(android.graphics.Color.BLACK)
                            } },
                            update = {
                                it.player = player
                                it.resizeMode = if (fitMode) AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    else AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            },
                            modifier = Modifier.fillMaxSize().graphicsLayer {
                                rotationZ = rotationDegrees.toFloat()
                                scaleX = if (mirror) -1f else 1f
                            }
                        )
                        androidx.compose.foundation.Image(
                            painter = painterResource(id = R.drawable.satria_logo),
                            contentDescription = "Watermark SATRIA",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp).size(52.dp)
                        )
                        if (!isPlaying) {
                            Surface(
                                color = Color(0x99000000), shape = RoundedCornerShape(50),
                                modifier = Modifier.align(Alignment.Center).size(70.dp)
                                    .clickable { player.play(); message = "Video sedang diputar" }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(46.dp))
                                }
                            }
                        }
                        IconButton(
                            onClick = { fullscreen = true },
                            modifier = Modifier.align(Alignment.TopEnd)
                                .padding(6.dp).background(Color(0x88000000), RoundedCornerShape(50))
                        ) {
                            Icon(Icons.Default.Fullscreen, "Layar penuh", tint = Color.White)
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(message, color = Color.LightGray, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { picker.launch(arrayOf("video/*")) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.FolderOpen, null)
                Spacer(Modifier.width(8.dp))
                Text(if (videoUri == null) "AMBIL VIDEO DARI GALERI" else "GANTI VIDEO", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            if (player.isPlaying) player.pause()
                            else if (videoUri != null) player.play()
                        },
                        enabled = videoUri != null
                    ) {
                        Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Cyan)
                    }
                    Text(if (isPlaying) "Jeda" else "Putar", color = Color.White, fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ulang", color = Color.White, fontSize = 12.sp)
                    Switch(checked = loop, onCheckedChange = { loop = it })
                }
                IconButton(onClick = { muted = !muted }, enabled = videoUri != null) {
                    Icon(if (muted || volume == 0f) Icons.Default.VolumeOff else Icons.Default.VolumeUp, null, tint = Cyan)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Volume", color = Color.White, fontSize = 11.sp)
                Slider(
                    value = volume,
                    onValueChange = { volume = it; if (it > 0f) muted = false },
                    valueRange = 0f..1f,
                    enabled = videoUri != null,
                    modifier = Modifier.weight(1f)
                )
                Text("${(volume * 100).toInt()}%", color = Cyan, fontSize = 11.sp)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { rotationDegrees = (rotationDegrees + 90) % 360 }, enabled = videoUri != null) {
                    Icon(Icons.Default.RotateRight, null); Spacer(Modifier.width(4.dp))
                    Text("Putar ${rotationDegrees}°")
                }
                TextButton(onClick = { mirror = !mirror }, enabled = videoUri != null) {
                    Icon(Icons.Default.Flip, null); Spacer(Modifier.width(4.dp))
                    Text(if (mirror) "Balik: ON" else "Balik: OFF")
                }
                TextButton(onClick = { fitMode = !fitMode }, enabled = videoUri != null) {
                    Icon(Icons.Default.AspectRatio, null); Spacer(Modifier.width(4.dp))
                    Text(if (fitMode) "Fit" else "Zoom")
                }
            }
            Text(
                "SATRIA LIVE hanya memutar video dari galeri. Tampilan Fit menjaga seluruh gambar tetap terlihat. Jika video miring, gunakan tombol Putar 90°. Untuk menampilkan preview saat LIVE, gunakan berbagi layar jika tersedia.",
                color = Color(0xFFFFC979), fontSize = 10.sp, lineHeight = 14.sp
            )
        }
    }

    if (fullscreen && videoUri != null) {
        Dialog(
            onDismissRequest = { fullscreen = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
                AndroidView(
                    factory = { PlayerView(it).apply {
                        this.player = player
                        useController = true
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                    } },
                    update = { it.player = player; it.useController = true },
                    modifier = Modifier.fillMaxWidth().weight(1f).graphicsLayer {
                        rotationZ = rotationDegrees.toFloat()
                    }
                )
                IconButton(
                    onClick = { fullscreen = false },
                    modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
                        .background(Color(0x88000000), RoundedCornerShape(50))
                ) {
                    Icon(Icons.Default.Close, "Tutup layar penuh", tint = Color.White)
                }
            }
        }
    }
}
