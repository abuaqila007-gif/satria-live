# SATRIA LIVE — Video Studio 0.2.0

Pembaruan:
- Memilih video dari galeri melalui pemilih dokumen Android.
- Izin baca video disimpan agar akses URI lebih tahan setelah aplikasi ditutup (bergantung penyedia galeri).
- Preview video dengan tombol putar/jeda.
- Pemutaran ulang (loop) dan mute.
- Watermark logo SATRIA di atas preview.
- Balik horizontal (mirror) dan pilihan tampilan Fit/Zoom.
- GitHub Actions menghasilkan APK debug.

## Cara build dari HP Android
1. Unggah isi folder `SATRIA-LIVE` ke repository GitHub (jangan mengunggah folder pembungkusnya).
2. Buka **Actions** → **Build SATRIA LIVE APK**.
3. Tekan **Run workflow** atau lakukan commit/push.
4. Buka run yang berhasil (tanda centang hijau).
5. Unduh artifact **SATRIA-LIVE-debug-apk**.
6. Ekstrak artifact dan instal `app-debug.apk`.

## Batasan penting
Video galeri diputar di dalam SATRIA LIVE. Watermark SATRIA ditampilkan pada preview aplikasi. Aplikasi Android biasa tidak dapat membuat kamera virtual sistem yang otomatis dikenali TikTok LIVE sebagai kamera fisik. Untuk menampilkan video di siaran, gunakan fitur berbagi layar/screen share di aplikasi LIVE jika tersedia. Overlay watermark dalam preview tidak otomatis ikut jika aplikasi lain hanya menangkap kamera, bukan layar.

Modul APP CLONER dan VIRTUAL CAMERA masih berupa penanda fitur, belum aktif.

## Detail
- Package: `id.satria.live`
- Version: `0.2.0` (versionCode 2)
- Min Android: 8.0 (API 26)
- Target SDK: 35
- Kotlin + Jetpack Compose + AndroidX Media3 ExoPlayer
