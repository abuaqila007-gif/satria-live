# SATRIA LIVE — Video Galeri 0.3.0

Versi ini difokuskan hanya untuk memilih dan memutar video dari galeri ponsel.

## Fitur
- Pilih video dari galeri melalui pemilih dokumen Android.
- Preview video menggunakan AndroidX Media3 ExoPlayer.
- Putar dan jeda.
- Pemutaran berulang (loop).
- Mute / suara.
- Balik horizontal (mirror).
- Pilihan tampilan Fit / Zoom.
- Mode layar penuh dengan kontrol pemutar.
- Watermark logo SATRIA pada preview utama.

## Build APK melalui GitHub Actions
1. Unggah `SATRIA-LIVE-PROJECT.zip` ke direktori utama repository.
2. Ganti isi `.github/workflows/build.yml` dengan file `build.yml` dari paket upload.
3. Commit perubahan.
4. Buka Actions → Build SATRIA LIVE APK.
5. Setelah run berhasil (centang hijau), buka Artifacts.
6. Unduh `SATRIA-LIVE-debug-apk`, ekstrak, lalu instal `app-debug.apk`.

## Batasan
Aplikasi ini hanya memutar video galeri di layar SATRIA LIVE. Untuk menampilkan video pada siaran, gunakan fitur berbagi layar/screen share pada aplikasi LIVE jika tersedia. Aplikasi ini tidak membuat kamera virtual Android dan tidak mengirim video sebagai input kamera TikTok.

## Detail
- Package: `id.satria.live`
- Version: `0.3.0` (versionCode 3)
- Minimum Android: 8.0 (API 26)
- Kotlin + Jetpack Compose + AndroidX Media3 ExoPlayer
