package id.satria.live

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

private val Navy = Color(0xFF080D18)
private val Panel = Color(0xFF121C2D)
private val Cyan = Color(0xFF43D5FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SatriaLiveApp() }
    }
}

@Composable
private fun SatriaLiveApp() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var loop by remember { mutableStateOf(true) }
    var muted by remember { mutableStateOf(false) }
    var mirror by remember { mutableStateOf(false) }
    var fitMode by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Pilih video dari galeri untuk memulai") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) { }
            videoUri = uri
            isPlaying = false
            message = "Video galeri siap diputar"
        }
    }

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }
    LaunchedEffect(videoUri, loop, muted) {
        player.repeatMode = if (loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        player.volume = if (muted) 0f else 1f
        videoUri?.let {
            player.setMediaItem(MediaItem.fromUri(it))
            player.prepare()
            player.playWhenReady = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
        Column(
            Modifier.fillMaxSize().background(Navy).padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.satria_logo),
                    contentDescription = "Logo SATRIA",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(68.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("SATRIA LIVE", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("CLONE • VIDEO STUDIO", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Surface(color = Color(0xFF153C38), shape = RoundedCornerShape(30.dp)) {
                    Text("BETA", color = Color(0xFF6EF0C2), modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("VIDEO STUDIO", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text("Pilih video galeri, atur tampilan, lalu putar sebagai sumber konten.", color = Color.LightGray, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))

            Surface(
                color = Panel, shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().weight(1f, fill = false)
            ) {
                Column(Modifier.padding(12.dp)) {
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(9f / 16f)
                            .background(Color.Black, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (videoUri == null) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxSize().clickable { picker.launch(arrayOf("video/*")) },
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.VideoLibrary, null, tint = Cyan, modifier = Modifier.size(58.dp))
                                Spacer(Modifier.height(10.dp))
                                Text("PREVIEW VIDEO", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Belum ada video dipilih", color = Color.Gray, fontSize = 11.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("KETUK UNTUK MEMILIH VIDEO", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            AndroidView(
                                factory = { PlayerView(it).apply {
                                    this.player = player
                                    useController = false
                                    resizeMode = if (fitMode) AspectRatioFrameLayout.RESIZE_MODE_FIT else AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                                } },
                                update = {
                                    it.player = player
                                    it.resizeMode = if (fitMode) AspectRatioFrameLayout.RESIZE_MODE_FIT else AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                },
                                modifier = Modifier.fillMaxSize().graphicsLayer {
                                    scaleX = if (mirror) -1f else 1f
                                }
                            )
                            // Watermark is drawn by SATRIA LIVE over the preview.
                            Image(
                                painter = painterResource(id = R.drawable.satria_logo),
                                contentDescription = "Watermark SATRIA",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp)
                                    .size(58.dp)
                            )
                            if (!isPlaying) {
                                Surface(
                                    color = Color(0x99000000),
                                    shape = RoundedCornerShape(50),
                                    modifier = Modifier.align(Alignment.Center).size(66.dp)
                                        .clickable { player.play(); message = "Video sedang diputar" }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(42.dp))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(9.dp))
                    Text(message, color = Color.LightGray, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { picker.launch(arrayOf("video/*")) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.FolderOpen, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (videoUri == null) "AMBIL VIDEO DARI GALERI" else "GANTI VIDEO GALERI", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(5.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    if (player.isPlaying) player.pause()
                                    else if (videoUri != null) player.play()
                                },
                                enabled = videoUri != null
                            ) {
                                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Cyan)
                            }
                            Text(if (isPlaying) "Jeda" else "Putar", color = Color.White, fontSize = 11.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Ulang", color = Color.White, fontSize = 11.sp)
                            Switch(checked = loop, onCheckedChange = { loop = it })
                        }
                        IconButton(onClick = { muted = !muted }) {
                            Icon(if (muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, null, tint = Cyan)
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { mirror = !mirror }, enabled = videoUri != null) {
                            Icon(Icons.Default.Flip, null); Spacer(Modifier.width(4.dp))
                            Text(if (mirror) "Balik: ON" else "Balik: OFF")
                        }
                        TextButton(onClick = { fitMode = !fitMode }, enabled = videoUri != null) {
                            Icon(Icons.Default.AspectRatio, null); Spacer(Modifier.width(4.dp))
                            Text(if (fitMode) "Fit" else "Zoom")
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("MODUL APLIKASI", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            FeatureTile(Icons.Default.Apps, "APP CLONER", "Modul kloning aplikasi — tahap pengembangan")
            Spacer(Modifier.height(8.dp))
            FeatureTile(Icons.Default.CameraAlt, "VIRTUAL CAMERA", "Belum tersedia sebagai kamera sistem Android")
            Spacer(Modifier.height(10.dp))
            Text(
                "CATATAN: Video diputar di SATRIA LIVE dan dapat ditampilkan melalui fitur berbagi layar jika aplikasi LIVE mendukungnya. Watermark terlihat pada preview. Aplikasi ini belum mengirim video sebagai input kamera virtual ke TikTok.",
                color = Color(0xFFFFC979), fontSize = 10.sp, lineHeight = 14.sp
            )
        }
    }
}

@Composable
private fun FeatureTile(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(25.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(subtitle, color = Color.LightGray, fontSize = 10.sp)
            }
            Icon(Icons.Default.Lock, null, tint = Color.Gray)
        }
    }
}
