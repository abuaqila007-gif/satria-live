# SATRIA LIVE — prototipe Android

Versi awal 0.1.0. Proyek ini membuat aplikasi Android native dengan pemilih video galeri, preview/pemutaran video, Play/Pause, Loop, dan mute.

## Batas fungsi versi ini
- Video diputar di dalam aplikasi SATRIA LIVE.
- Belum membuat kamera virtual tingkat sistem; Android biasa tidak menyediakan API publik untuk membuat aplikasi lain menganggap pemutar video ini sebagai kamera fisik.
- Belum mengkloning aplikasi lain. Fitur clone penuh memerlukan lingkungan virtualisasi Android khusus, kompatibilitas aplikasi, serta pengujian keamanan dan kebijakan platform. Tidak ada kode internal APK referensi yang disalin.
- Jangan menganggap video preview otomatis dapat dipakai sebagai input TikTok/Facebook LIVE.

## Build APK dari HP Android (tanpa laptop)
1. Buat repository GitHub baru bernama `satria-live`.
2. Unggah seluruh isi folder proyek ini ke repository (bukan folder luarnya).
3. Buka tab **Actions**, pilih workflow **Build SATRIA LIVE APK**, lalu tekan **Run workflow**.
4. Setelah selesai, buka hasil run dan unduh artifact `SATRIA-LIVE-debug-apk`.
5. Ekstrak ZIP artifact; file instalasi adalah `app-debug.apk`.
6. Instal APK pada perangkat Android. Izinkan instalasi dari sumber yang Anda gunakan bila diminta.

## Detail teknis
- Package: `id.satria.live`
- Min Android: 8.0 (API 26)
- Target SDK: 35
- Kotlin + Jetpack Compose + AndroidX Media3 ExoPlayer
