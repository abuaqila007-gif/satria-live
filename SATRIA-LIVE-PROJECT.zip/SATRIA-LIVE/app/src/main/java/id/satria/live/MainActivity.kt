package id.satria.live

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Navy = Color(0xFF080D18)
private val Panel = Color(0xFF121C2D)
private val Cyan = Color(0xFF43D5FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SatriaLiveApp() }
    }
}

@Composable
private fun SatriaLiveApp() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var loop by remember { mutableStateOf(true) }
    var muted by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Pilih video dari galeri untuk memulai") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { videoUri = uri; message = "Video siap diputar" }
    }
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) { onDispose { player.release() } }
    LaunchedEffect(videoUri, loop, muted) {
        player.repeatMode = if (loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        player.volume = if (muted) 0f else 1f
        videoUri?.let { player.setMediaItem(MediaItem.fromUri(it)); player.prepare(); player.playWhenReady = false }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Navy).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(Cyan, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Videocam, null, tint = Navy, modifier = Modifier.size(29.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("SATRIA LIVE", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("CLONE • VIDEO STUDIO", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Surface(color = Color(0xFF153C38), shape = RoundedCornerShape(30.dp)) {
                    Text("BETA", color = Color(0xFF6EF0C2), modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(22.dp))
            Text("VIDEO STUDIO", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("Gunakan video galeri sebagai bahan siaran", color = Color.LightGray, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().weight(1f, fill = false)) {
                Column(Modifier.padding(12.dp)) {
                    Box(Modifier.fillMaxWidth().aspectRatio(9f / 16f).background(Color.Black, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        if (videoUri == null) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.VideoLibrary, null, tint = Cyan, modifier = Modifier.size(54.dp))
                                Spacer(Modifier.height(8.dp)); Text("PREVIEW VIDEO", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Belum ada video dipilih", color = Color.Gray, fontSize = 11.sp)
                            }
                        } else {
                            AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, update = { it.player = player }, modifier = Modifier.fillMaxSize())
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(message, color = Color.LightGray, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { picker.launch("video/*") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("PILIH VIDEO DARI GALERI", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { if (player.isPlaying) { player.pause(); isPlaying = false } else { player.play(); isPlaying = true } }, enabled = videoUri != null) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Cyan) }; Text(if (isPlaying) "Pause" else "Play", color = Color.White, fontSize = 12.sp) }
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("Loop", color = Color.White, fontSize = 12.sp); Switch(checked = loop, onCheckedChange = { loop = it }) }
                        IconButton(onClick = { muted = !muted }) { Icon(if (muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, null, tint = Cyan) }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("MODUL APLIKASI", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(9.dp))
            FeatureTile(Icons.Default.Apps, "APP CLONER", "Modul kloning aplikasi — tahap pengembangan", false)
            Spacer(Modifier.height(8.dp))
            FeatureTile(Icons.Default.CameraAlt, "VIRTUAL CAMERA", "Belum aktif: perlu integrasi tingkat sistem dan uji kompatibilitas", false)
            Spacer(Modifier.height(12.dp))
            Text("Catatan: preview ini memutar video di SATRIA LIVE. Belum mengirim video sebagai kamera ke TikTok/Facebook LIVE.", color = Color(0xFFFFC979), fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable
private fun FeatureTile(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, enabled: Boolean) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(25.dp)); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text(subtitle, color = Color.LightGray, fontSize = 10.sp) }
            Icon(if (enabled) Icons.Default.CheckCircle else Icons.Default.Lock, null, tint = if (enabled) Cyan else Color.Gray)
        }
    }
}
